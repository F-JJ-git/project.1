#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "输入 n（n >= 1）：";
    cin >> n;
    if (n < 1) {
        cout << "n 必须大于等于 1。\n";
        return 1;
    }

    long long x = 0;
    long long count = 0;
    for (int i = 1; i <= n - 1; ++i) {
        for (int j = i + 1; j <= n; ++j) {
            x = x - 1;
            ++count;
        }
    }

    cout << "语句 x = x - 1 的实际执行次数：" << count << '\n';
    cout << "理论公式 n(n-1)/2：" << 1LL * n * (n - 1) / 2 << '\n';
    cout << "最终 x：" << x << '\n';
    return 0;
}
