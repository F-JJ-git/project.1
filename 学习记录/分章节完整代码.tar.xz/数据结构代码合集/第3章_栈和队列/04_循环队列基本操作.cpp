#include <iostream>
#include <vector>
using namespace std;

class CircularQueue {
private:
    vector<int> data;
    int front, rear, count;
public:
    explicit CircularQueue(int capacity) : data(capacity), front(0), rear(0), count(0) {}
    bool Empty() const { return count == 0; }
    bool Full() const { return count == static_cast<int>(data.size()); }
    bool EnQueue(int e) {
        if (Full()) return false;
        data[rear] = e;
        rear = (rear + 1) % static_cast<int>(data.size());
        ++count;
        return true;
    }
    bool DeQueue(int& e) {
        if (Empty()) return false;
        e = data[front];
        front = (front + 1) % static_cast<int>(data.size());
        --count;
        return true;
    }
    void Display() const {
        cout << "队列：";
        for (int i = 0; i < count; ++i) cout << data[(front + i) % data.size()] << ' ';
        cout << '\n';
    }
};

int main() {
    CircularQueue q(3);
    q.EnQueue(10); q.EnQueue(20); q.EnQueue(30);
    q.Display();
    cout << "尝试入队40：" << (q.EnQueue(40) ? "成功" : "队满") << '\n';
    int e;
    q.DeQueue(e); cout << "出队：" << e << '\n';
    q.EnQueue(40);
    q.Display();
    return 0;
}
