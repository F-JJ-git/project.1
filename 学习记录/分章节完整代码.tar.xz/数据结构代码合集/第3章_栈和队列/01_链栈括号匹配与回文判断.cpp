#include <iostream>
#include <string>
using namespace std;

struct CharNode {
    char data;
    CharNode* next;
    explicit CharNode(char c, CharNode* n = nullptr) : data(c), next(n) {}
};

class CharStack {
private:
    CharNode* top;
public:
    CharStack() : top(nullptr) {}
    ~CharStack() { char c; while (Pop(c)) {} }
    CharStack(const CharStack&) = delete;
    CharStack& operator=(const CharStack&) = delete;
    bool Empty() const { return top == nullptr; }
    void Push(char c) { top = new CharNode(c, top); }
    bool Pop(char& c) {
        if (!top) return false;
        CharNode* p = top; c = p->data; top = p->next; delete p; return true;
    }
};

bool IsPalindrome(const string& s) {
    CharStack st;
    size_t n = s.size();
    for (size_t i = 0; i < n / 2; ++i) st.Push(s[i]);
    size_t i = (n % 2 == 0) ? n / 2 : n / 2 + 1; // 奇数长度跳过中间字符
    char c;
    for (; i < n; ++i) {
        if (!st.Pop(c) || c != s[i]) return false;
    }
    return st.Empty();
}

bool MatchBrackets(const string& s) {
    CharStack st;
    for (char c : s) {
        if (c == '(' || c == '[' || c == '{') st.Push(c);
        else if (c == ')' || c == ']' || c == '}') {
            char left;
            if (!st.Pop(left)) return false;
            if (!((left == '(' && c == ')') || (left == '[' && c == ']') || (left == '{' && c == '}'))) return false;
        }
    }
    return st.Empty();
}

int main() {
    int choice;
    cout << "1.回文判断  2.括号匹配\n请选择：";
    cin >> choice;
    string s;
    cout << "输入字符串：";
    cin >> s;
    if (choice == 1) cout << (IsPalindrome(s) ? "是回文\n" : "不是回文\n");
    else if (choice == 2) cout << (MatchBrackets(s) ? "括号匹配正确\n" : "括号匹配错误\n");
    else cout << "选项无效。\n";
    return 0;
}
