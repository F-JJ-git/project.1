#include <iostream>
using namespace std;

struct Node {
    double data;
    Node* next;
    explicit Node(double e = 0, Node* p = nullptr) : data(e), next(p) {}
};

class SensorQueue {
private:
    Node* front; // 头结点，不保存有效数据
    Node* rear;
    int maxSize;
    int count;
    double sum;
public:
    explicit SensorQueue(int n) : front(new Node()), rear(front), maxSize(n), count(0), sum(0) {}
    ~SensorQueue() {
        while (front) { Node* p = front; front = front->next; delete p; }
    }
    SensorQueue(const SensorQueue&) = delete;
    SensorQueue& operator=(const SensorQueue&) = delete;

    double AddData(double e) {
        if (count == maxSize) { // 满时先删除最早采集的数据
            Node* old = front->next;
            sum -= old->data;
            front->next = old->next;
            if (rear == old) rear = front;
            delete old;
            --count;
        }
        Node* p = new Node(e);
        rear->next = p;
        rear = p;
        sum += e;
        ++count;
        return sum / count;
    }
    void Display() const {
        cout << "当前窗口：";
        for (Node* p = front->next; p; p = p->next) cout << p->data << (p->next ? " -> " : "");
        cout << "\n";
    }
};

int main() {
    int n, m;
    cout << "输入数据区容量 n："; cin >> n;
    if (n <= 0) { cout << "容量必须大于0。\n"; return 1; }
    cout << "输入采集次数："; cin >> m;
    if (m < 0) { cout << "次数不能为负数。\n"; return 1; }
    SensorQueue q(n);
    for (int i = 0; i < m; ++i) {
        double e;
        cout << "输入新采集的数据："; cin >> e;
        cout << "当前平均值：" << q.AddData(e) << '\n';
        q.Display();
    }
    return 0;
}
